# Methodologie - Informatique 2023

## Liens youtube

### "Les douze mensonges du GIEC" - Christian Gérondeau (46:55)

Lien : <https://www.youtube.com/watch?v=0nS0P2fv7sE>

[Lien vers la retranscription](https://ubcloud.u-bordeaux.fr/apps/files/?dir=/4TPU202U%20M%C3%A9thodologie%20scientifique/Ressources&fileid=3413614)

### WCF 2021 - The Power of Youth - Naomi Seibt (17:01)

Lien : <https://www.youtube.com/watch?v=Ji6H1_Ui-Iw>

[Lien vers la retranscription](https://ubcloud.u-bordeaux.fr/apps/files/?dir=/4TPU202U%20M%C3%A9thodologie%20scientifique/Ressources&fileid=3413614)

### Vincent Courtillot : "Il n'y a plus aucun réchauffement climatique" (25:18)

Lien : <https://www.youtube.com/watch?v=pNThA15OyFU>

[Lien vers la retranscription](https://ubcloud.u-bordeaux.fr/apps/files/?dir=/4TPU202U%20M%C3%A9thodologie%20scientifique/Ressources&fileid=3413614)

## Autres références

<https://www.frontiersin.org/articles/10.3389/fcomm.2019.00036/full>

## Outils

Télécharger les sous-titres d'une vidéo youtube : <https://downsub.com/>