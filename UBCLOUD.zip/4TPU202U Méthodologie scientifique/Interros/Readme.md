# Interros année 2021-2022

2 interros ont eu lieu au cours du semestre (durée approx 20 - 30 minutes)

Il y a à chaque fois deux sujets, puisque j'avais (GM) deux groupes.

Seule la première interro a un corrigé.