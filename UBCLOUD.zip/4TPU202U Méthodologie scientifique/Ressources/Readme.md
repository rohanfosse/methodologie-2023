# Ressources

Ce dossier contient différents documents qui pourront servir de support pour les projets des étudiants, mais aussi pour les séances ou nous aborderons les notions d'argumentation paralogique, les biais cognitifs, les arguments fallacieux.