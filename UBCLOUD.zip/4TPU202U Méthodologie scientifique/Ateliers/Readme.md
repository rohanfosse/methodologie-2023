# Ateliers

Le cours est structuré en ateliers (3) abordant différents thèmes autour du raisonnement scientifique, auquel s'ajoute un "projet" que les étudiants font en équipe.

Les présentations sont des supports utilisés en séances pour présentés les différents notions: raisonnement scientifique; incertitudes et erreurs; communication et visualisation (de résultats et données scientifiques).

Le déroulé du semestre fait en sorte qu'on peut difficilement tester les étudiants sur les trois volets mais seulement les deux premiers. J'avais (GM) pris un peu de liberté pour le troisième volet en présentant des choses sur la visualisation de manière générale.